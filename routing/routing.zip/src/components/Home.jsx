import React, { Component } from 'react'

export class Home extends Component {
  render() {
    return (
        <fieldset>
            <legend>Home.jsx</legend>
      <div style={{textAlign:'center'}}>
          <h1>Welcome</h1>
      </div>
        </fieldset>
    )
  }
}

export default Home